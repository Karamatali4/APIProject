import React from 'react'

function Footer() {

  return (
    <>
    <div className="row footer mt-5 " >
        <div className="col col-12 col-md-12 text-center">
        <p>Copyright © 2024  Developed by Karamat uses API</p>

        </div>
    </div>
    </>
  )
}

export default Footer